'''
@author eoporter
'''

import torch

### Helper funcitons
def has_tke(output_features):
    names = [n.lower() for n in output_features]
    return 'tke' in names or 'k' in names

def tke_index(output_features):
    names = [n.lower() for n in output_features]
    return names.index('tke') if 'tke' in names else names.index('k')

def extract_aij_and_k(tensor, output_features):
    """
    For aij-family outputs like [... a_xx, a_xy, a_yy, a_xz, a_yz, a_zz, tke]
    returns (aij_vec6, k_vec1). Assumes canonical order of the 6 a_ij comps.
    """
    a_idx = get_indices(AIJ6, output_features)
    aij = tensor[:, a_idx]
    k = None
    if has_tke(output_features):
        k = tensor[:, tke_index(output_features)]
    return aij, k


RST6 = ['uu','uv','vv','uw','vw','ww']
AIJ6 = ['a_xx','a_xy','a_yy','a_xz','a_yz','a_zz']
BIJ6 = ['b_xx','b_xy','b_yy','b_xz','b_yz','b_zz']

def detect_family(output_features):
    names = [n.lower() for n in output_features]
    if any(n.startswith('a_') for n in names):  # e.g., a_xx
        return 'aij'
    if any(n.startswith('b_') for n in names):  # e.g., b_xx
        return 'bij'
    return 'rst'

def extract_six(preds, output_features, family):
    """
    Returns a [N,6] tensor in the canonical RST ordering positions
    (uu, uv, vv, uw, vw, ww) but containing the requested family’s values.
    """
    if family == 'rst':
        names = RST6
    elif family == 'aij':
        names = AIJ6
    elif family == 'bij':
        names = BIJ6
    else:
        raise ValueError(f"Unknown family {family}")

    idxs = get_indices(names, output_features)
    return preds[:, idxs], names

def get_indices(targets, output_features):
    """
    Map target feature names to their indices in the model output vector.
    """
    indices = []
    for feature in targets:
        try:
            idx = output_features.index(feature)
            indices.append(idx)
        except ValueError:
            raise ValueError(f"Feature '{feature}' not found in output features.")
    return indices

def ij_from_name(name):
    """
    Maps 'uu', 'uv', 'vv' → '11', '12', '22', etc.
    Useful for naming a_ij, b_ij component-wise.
    """
    mapping = {'u': '1', 'v': '2', 'w': '3'}
    if len(name) != 2:
        raise ValueError(f"Invalid RST component name: {name}")
    return f"{mapping[name[0]]}{mapping[name[1]]}"


def extract_rst(preds, output_features, rst_order=['uu', 'uv', 'vv', 'uw', 'vw', 'ww']):
    """
    Extract RST components from the model predictions.
    Returns: tensor[N, len(rst_order)], ordered_feature_names
    """
    indices = get_indices(rst_order, output_features)
    return preds[:, indices], [output_features[i] for i in indices]

def extract_aij(preds, output_features, rst_order=['a_xx', 'a_xy', 'a_yy', 'a_xz', 'a_yz', 'a_zz']):
    """
    Extract RST components from the model predictions.
    Returns: tensor[N, len(rst_order)], ordered_feature_names
    """
    indices = get_indices(rst_order, output_features)
    return preds[:, indices], [output_features[i] for i in indices]




def compute_k(tij, output_features):
    """
    Compute turbulent kinetic energy k from the normal stress components.
    """
    idxs = get_indices(['uu', 'vv', 'ww'], output_features)
    t_ii = tij[:, idxs]  # shape: (batch, 3)
    k = 0.5 * t_ii.sum(dim=1)  # shape: (batch,)
    return k


def compute_aij(t_ij, tke, output_features):
    """
    Compute anisotropy tensor a_ij from RST and k.
    """
    a_ij = torch.zeros_like(t_ij)  # shape: (batch, C)
    two_thirds_k = (2.0 / 3.0) * tke.unsqueeze(1)  # shape: (batch, 1)
    for i, name in enumerate(output_features):
        if name in ['uu', 'vv', 'ww']:
            a_ij[:, i] = t_ij[:, i] - two_thirds_k.squeeze(1)
        else:
            a_ij[:, i] = t_ij[:, i]
    return a_ij


def compute_bij(t_ij, tke, output_features):
    """
    Compute normalized anisotropy tensor b_ij from a_ij and k.
    """
    two_k = 2.0 * tke.view(-1, 1)
    b_ij =t_ij/two_k #shape: (batch, C)
    
    # Subtract 1/3 from diagonals
    for i, name in enumerate(output_features):
        if name in ['uu', 'vv', 'ww']:
            b_ij[:, i] -= 1.0 / 3.0

    return b_ij


def compute_tr_aij(a_ij, output_features):
    """
    Compute the trace of the anisotropy tensor a_ijS
    Should be close to zero as a constraint.
    """
    diag_indices = get_indices(['uu', 'vv', 'ww'], output_features)
    return a_ij[:, diag_indices].sum(dim=1)

def compute_tr_bij(b_ij, output_features):
    """
    Compute the trace of the anisotropy tensor a_ij
    Should be close to zero as a constraint.
    """
    diag_indices = get_indices(['uu', 'vv', 'ww'], output_features)
    return b_ij[:, diag_indices].sum(dim=1)


def compute_invariants_tensor(tensor_batch, output_features=None):
    """
    Assumes tensor_batch is [N,6] in canonical order:
    [xx, xy, yy, xz, yz, zz] mapped to matrix
        [[xx, xy, xz],
         [xy, yy, yz],
         [xz, yz, zz]]
    Works for RST, a_ij, or b_ij as long as the vector is in that order.
    """
    a = tensor_batch
    xx, xy, yy, xz, yz, zz = a[:,0], a[:,1], a[:,2], a[:,3], a[:,4], a[:,5]
    I1 = xx + yy + zz
    # I2 = -a_ij a_ji  (for symmetric 3x3 => formula below)
    I2 = -(xx*xx + yy*yy + zz*zz + 2*(xy*xy + xz*xz + yz*yz))

    # I3 = det(A) for symmetric 3x3
    I3 = (
        xx*(yy*zz - yz*yz)
        - xy*(xy*zz - xz*yz)
        + xz*(xy*yz - xz*yy)
    )
    return I1, I2, I3

def compute_eigenvalues_batch(tensor_batch):
    """
    Converts [N,6] vec6 -> [N,3,3] using the same canonical order as above.
    """
    a = tensor_batch
    N = a.shape[0]
    mat = torch.zeros((N, 3, 3), dtype=a.dtype, device=a.device)
    mat[:,0,0] = a[:,0]  # xx
    mat[:,0,1] = mat[:,1,0] = a[:,1]  # xy
    mat[:,1,1] = a[:,2]  # yy
    mat[:,0,2] = mat[:,2,0] = a[:,3]  # xz
    mat[:,1,2] = mat[:,2,1] = a[:,4]  # yz
    mat[:,2,2] = a[:,5]  # zz
    return torch.linalg.eigvalsh(mat)




from copy import deepcopy
def compute_feature_loss(pred, label, criterion, standard=False):
    """
    Compute mean component loss using per-element criterion.
    """
    # Clone the criterion with no reduction
    criterion_no_reduce = type(criterion)(reduction='none')
    
    # Standard loss per element
    per_element_loss = criterion_no_reduce(pred, label)  # shape: [batch, features]
     
    # Sum of per-element loss
    standard_loss = torch.sum(torch.abs(per_element_loss))
    
    if standard:
        return standard_loss
    # Energy difference loss (squared component diff)
    energy_diff = pred**2 - label**2
    energy_loss = torch.sum(torch.abs(energy_diff))
     
    # Combined
    total_loss = 0.5 * (standard_loss + energy_loss)

    return total_loss



def make_phys_losses(config, pred, truth, criterion):
    phys_cfg = config['training']['loss']['terms']['phys']
    if not phys_cfg.get('enabled', False):
        return None
    types = [t.lower() for t in phys_cfg.get('types', [])]
    if not types:
        return None

    output_features = config['features']['output']
    family = detect_family(output_features)
    loss = {}

    if family == 'rst':
        # existing path (unchanged)
        t_pred, _ = extract_rst(pred, output_features)
        t_true, _ = extract_rst(truth, output_features)

        if 'tke' in types or 'k' in types:
            k_p = compute_k(t_pred, RST6)
            k_t = compute_k(t_true, RST6)
            loss['TKE'] = compute_feature_loss(k_p, k_t, criterion)

        if 'aij' in types or 'a_ij' in types or 'anisotropy' in types or 'a' in types:
            k_p = compute_k(t_pred, RST6); k_t = compute_k(t_true, RST6)
            a_p = compute_aij(t_pred, k_p, RST6); a_t = compute_aij(t_true, k_t, RST6)
            for i, nm in enumerate(RST6):
                loss[f'a_{ij_from_name(nm)}'] = compute_feature_loss(a_p[:,i], a_t[:,i], criterion)

        if 'bij' in types or 'b_ij' in types or 'normalized_anisotropy' in types or 'b' in types:
            k_p = compute_k(t_pred, RST6); k_t = compute_k(t_true, RST6)
            b_p = compute_bij(t_pred, k_p, RST6); b_t = compute_bij(t_true, k_t, RST6)
            for i, nm in enumerate(RST6):
                loss[f'b_{ij_from_name(nm)}'] = compute_feature_loss(b_p[:,i], b_t[:,i], criterion)

        return loss

    if family == 'aij':
        # a_ij is direct output; optionally derive b_ij using predicted k
        a_p, k_p = extract_aij_and_k(pred, output_features)
        a_t, k_t = extract_aij_and_k(truth, output_features)

        # optional TKE physics term
        if ('tke' in types or 'k' in types) and k_p is not None:
            scalar = float(config['training']['loss']['weights']['data']['tke_scalar'])
            loss['TKE'] = scalar * compute_feature_loss(k_p, k_t, criterion)

        # optional b_ij terms if you asked for them AND k exists
        if (('bij' in types) or ('b_ij' in types) or ('normalized_anisotropy' in types) or ('b' in types)) and (k_p is not None):
            two_k_p = 2.0 * k_p.view(-1,1)
            two_k_t = 2.0 * k_t.view(-1,1)
            b_p = a_p / (two_k_p + 1e-12)
            b_t = a_t / (two_k_t + 1e-12)
            # subtract 1/3 on diagonals
            for i, nm in enumerate([0,2,5]):  # xx,yy,zz positions
                b_p[:, nm] -= 1.0/3.0
                b_t[:, nm] -= 1.0/3.0
            # component losses (or replace with global Frobenius if you prefer)
            for i, nm in enumerate(['xx','xy','yy','xz','yz','zz']):
                loss[f'b_{nm}'] = compute_feature_loss(b_p[:,i], b_t[:,i], criterion)

        return loss

    if family == 'bij':
        # defer full bij support per your plan
        return {}

    raise ValueError(f"Unknown family {family}")




def make_constraint_losses(config, pred, truth, criterion, epoch=0):
    
    cfg = config['training']['loss']['terms'].get('constraint', {})
    if not cfg.get('enabled', False):
        return None
    types = [t.lower() for t in cfg.get('types', [])]
    if not types:
        return None
    #loss warmups
    warm_cfg = config['training']['loss'].get('warmup', {})
    eig_warm = int(warm_cfg.get('eigen', 0))
    inv_warm = int(warm_cfg.get('invariants', 0))
    def allow(kind: str):
        if 'eig' in kind and epoch < eig_warm:
            return False
        if kind.startswith('inv') and epoch < inv_warm:
            return False
        return True
    
    output_features = config['features']['output']
    family = detect_family(output_features)
    loss = {}

    def add_inv_and_eig(prefix, A_pred, A_true):
        I1_t,I2_t, I3_t = compute_invariants_tensor(A_true)
        I1_p, I2_p, I3_p = compute_invariants_tensor(A_pred)

        # ---- component invariants ----
        if allow('inv') and any(k in types for k in [f'inv_{prefix}_tr', f'inv_{prefix}_trace', f'inv_{prefix}_all']):
            loss[f'I1_{prefix}_tr'] = compute_feature_loss(I1_p, I1_t, criterion, True)

        if allow('inv') and any(k in types for k in [f'inv_{prefix}_comp', f'inv_{prefix}_component', f'inv_{prefix}_all']):
            loss[f'I2_{prefix}_comp'] = compute_feature_loss(I2_p, I2_t, criterion, True)
            loss[f'I3_{prefix}_comp'] = compute_feature_loss(I3_p, I3_t, criterion, True)

        # ---- eigen invariants ----
        if allow('eig') and any(k in types for k in [f'inv_{prefix}_eig', f'inv_{prefix}_eigen', f'inv_{prefix}_all',
                                                     f'inv_{prefix}_consistency', f'inv_{prefix}_consist']):
            eig_p = compute_eigenvalues_batch(A_pred)
            eig_t = compute_eigenvalues_batch(A_true)
            I1_eig_p = eig_p.sum(dim=1);  I2_eig_p = -torch.sum(eig_p**2, dim=1);  I3_eig_p = torch.prod(eig_p, dim=1)
            I1_eig_t = eig_t.sum(dim=1);  I2_eig_t = -torch.sum(eig_t**2, dim=1);  I3_eig_t = torch.prod(eig_t, dim=1)

            if any(k in types for k in [f'inv_{prefix}_eig', f'inv_{prefix}_eigen', f'inv_{prefix}_all']):
                loss[f'I1_{prefix}_eig'] = compute_feature_loss(I1_eig_p, I1_eig_t, criterion, True)
                loss[f'I2_{prefix}_eig'] = compute_feature_loss(I2_eig_p, I2_eig_t, criterion, True)
                loss[f'I3_{prefix}_eig'] = compute_feature_loss(I3_eig_p, I3_eig_t, criterion, True)

            if any(k in types for k in [f'inv_{prefix}_consistency', f'inv_{prefix}_consist', f'inv_{prefix}_all']):
                loss[f'I2_{prefix}_consistency'] = compute_feature_loss(I2_p, I2_eig_p, criterion, True)
                loss[f'I3_{prefix}_consistency'] = compute_feature_loss(I3_p, I3_eig_p, criterion, True)


    if family == 'rst':
        # original path (nest your current logic)
        t_p, _ = extract_rst(pred, output_features); k_p = compute_k(t_p, RST6)
        t_t, _ = extract_rst(truth, output_features); k_t = compute_k(t_t, RST6)
        a_p = compute_aij(t_p, k_p, RST6); b_p = compute_bij(t_p, k_p, RST6)
        a_t = compute_aij(t_t, k_t, RST6); b_t = compute_bij(t_t, k_t, RST6)

        if any('a' in k for k in types):
            add_inv_and_eig('a', a_p, a_t)
        if any('b' in k for k in types):
            add_inv_and_eig('b', b_p, b_t)
        return loss

    if family == 'aij':
        a_p, k_p = extract_aij_and_k(pred, output_features)
        a_t, k_t = extract_aij_and_k(truth, output_features)

        # Always allow a_ij invariants/eigs in aij-family
        add_inv_and_eig('a', a_p, a_t)

        # If k available, derive b_ij and add its invariants/eigs too
        if k_p is not None:
            two_k_p = 2.0 * k_p.view(-1,1);  two_k_t = 2.0 * k_t.view(-1,1)
            b_p = a_p / (two_k_p + 1e-12);  b_t = a_t / (two_k_t + 1e-15)
            for i in [0,2,5]:
                b_p[:, i] -= 1.0/3.0;  b_t[:, i] -= 1.0/3.0
            add_inv_and_eig('b', b_p, b_t)
        return loss

    if family == 'bij':
        # to be added later
        return {}

    raise ValueError(f"Unknown family {family}")


import torch.nn as nn
def make_data_losses(config, pred, truth, criterion=None):
    output_features = config['features']['output']
    family = detect_family(output_features)

    assert pred.shape == truth.shape and pred.ndim == 2
    N, C = pred.shape
    assert len(output_features) == C

    crit = type(criterion)(reduction='none')

    def per_elem_combo(p, t):
        pe = crit(p, t)                # [N,C] or [N]
        std = torch.sum(torch.abs(pe), dim=0) if p.ndim == 2 else torch.sum(torch.abs(pe))
        ediff = p**2 - t**2
        eloss = torch.sum(torch.abs(ediff), dim=0) if p.ndim == 2 else torch.sum(torch.abs(ediff))
        return 0.5*(std + eloss)

    out = {}

    if family == 'aij':
        # a_ij components
        a_idx = get_indices(AIJ6, output_features)
        a_loss = per_elem_combo(pred[:, a_idx], truth[:, a_idx])  # [6]
        for i, nm in enumerate(AIJ6):
            out[nm] = a_loss[i]
        # k (scalar) if present
        if has_tke(output_features):
            ki = tke_index(output_features)
            out['tke'] = per_elem_combo(pred[:, ki], truth[:, ki])
    else:
        # default: treat all columns as independent features (current behavior)
        total_loss = per_elem_combo(pred, truth)  # [C]
        for i, feature in enumerate(output_features):
            out[feature] = total_loss[i]

    out['net'] = torch.sum(torch.stack([v if torch.is_tensor(v) else torch.tensor(v, device=pred.device)
                                        for k,v in out.items() if k!='net']))
    return out




def compute_all_losses(config, pred, truth, criterion, y_frob_max, y_k_max, epoch=0):
    """
    Family-aware de-normalization before computing data/phys/constraint losses.
    - RST/BIJ: scale all outputs by y_frob_max (legacy behavior).
    - AIJ(+k): scale a_ij components by y_frob_max and k/tke by y_k_max (if provided).
    """
    losses = {}

    feats   = config['features']['output']
    family  = detect_family(feats)

    # work on clones to avoid side-effects upstream
    pred_d  = pred.clone()
    truth_d = truth.clone()

    # use .get to avoid KeyError if someone forgets to put the switch in cfg
    if config['features'].get('denorm_loss', False):
        if family == 'aij':
            # scale the six anisotropy channels
            a_idx = get_indices(AIJ6, feats)
            pred_d[:, a_idx]  *= y_frob_max
            truth_d[:, a_idx] *= y_frob_max

            # scale k/tke independently if present and scale provided
            if has_tke(feats) and (y_k_max is not None):
                ki = tke_index(feats)
                pred_d[:, ki]  *= y_k_max
                truth_d[:, ki] *= y_k_max
        else:
            # legacy path: RST/BIJ or anything else → single scaler
            pred_d  *= y_frob_max
            truth_d *= y_frob_max

    # === group losses ===
    data_cfg = config['training']['loss']['terms'].get('data', {})
    losses['data'] = make_data_losses(config, pred_d, truth_d, criterion) if data_cfg.get('enabled', False) else None

    phys_cfg = config['training']['loss']['terms'].get('phys', {})
    losses['phys'] = make_phys_losses(config, pred_d, truth_d, criterion) if phys_cfg.get('enabled', False) else None

    const_cfg = config['training']['loss']['terms'].get('constraint', {})
    losses['constraint'] = make_constraint_losses(config, pred_d, truth_d, criterion, epoch=epoch) if const_cfg.get('enabled', False) else None

    return losses

